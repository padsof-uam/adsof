package es.uam.padsof.batalla5ejercitos.criaturas;

/**
 * @author Guillermo Julián Moreno - Víctor de Juan Sanz
 * 
 */
public class Enano extends CriaturaLibre {

	public Enano(int ataque, int defensa, int vida) {
		super(ataque, defensa, vida);
	}

}
