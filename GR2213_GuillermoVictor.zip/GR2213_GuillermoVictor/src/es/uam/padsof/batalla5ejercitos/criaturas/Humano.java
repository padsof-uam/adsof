package es.uam.padsof.batalla5ejercitos.criaturas;

/**
 * @author Guillermo Julián Moreno - Víctor de Juan Sanz
 * 
 */
public class Humano extends CriaturaLibre {

	public Humano(int ataque, int defensa, int vida) {
		super(ataque, defensa, vida);
	}

}
