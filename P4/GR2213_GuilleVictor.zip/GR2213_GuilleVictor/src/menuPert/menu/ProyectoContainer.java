package menuPert.menu;

import menuPert.proyector.Proyecto;

/**
 * @author Guillermo Julián Moreno
 * @author Víctor de Juan Sanz
 * 
 */
public class ProyectoContainer {
	public Proyecto proyecto = null;
}
